<?php
/**
 * Created by PhpStorm.
 * User: 韩笑Thd
 * Date: 2017/6/19
 * Time: 17:31
 */
include "../admin/common.php";
$tel=isset($_POST['tel'])?$_POST['tel']:"";
$email=isset($_POST['email'])?$_POST['email']:"";
$name=isset($_POST['names'])?$_POST['names']:"";
$thumb=isset($_POST['thumb'])?$_POST['thumb']:"";
$sql="update friend set names='{$name}',tel='{$tel}',email='{$email}',portrait='{$thumb}' WHERE user='{$}'";
$result=$db->query($sql);
if ($result){
    echo "ok";
}else{
    echo "error";;
}

<?php
/**
 * Created by PhpStorm.
 * User: 韩笑Thd
 * Date: 2017/6/18
 * Time: 17:56
 */
include "../admin/common.php";
include "../lib/select.php";
echo checkname($db);
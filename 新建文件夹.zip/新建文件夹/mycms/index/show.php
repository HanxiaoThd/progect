<?php
session_start();
include "../admin/common.php";
include "header.php";
$id=$_GET['id'];
$sql="select * from lists WHERE id={$id}";
$result=$db->query($sql);
$row=$result->fetch_assoc();
?>
<link rel="stylesheet" href="../static/css/index/show.css">
<div class="container">
    <div class="col-xs-12">
        <h2 class="s-title">
            <?php echo $row['titles']?>
        </h2>
        <div class="author">
            <span><?php echo $row['author']?> </span>
            <span> <?php echo $row['times']?></span>
        </div>
        <div class="s-con"><?php echo $row['con']?></div>
    </div>
</div>
<div class="messageBox container">
    <div class="row">
        <div class="col-xs-12">
        <textarea  maxlength="120" placeholder="发表你的观点,可输入120个字" id="" cols="30" rows="10">

        </textarea>
            <button>发表</button>
        </div>
    </div>
    <div class="row">
        <ul class="col-xs-12">
            <li>
                <div class="headimg"></div>
                <div class="titlebox">
                    <div class="name"></div>
                    <div class="con"></div>
                </div>
            </li>
        </ul>
    </div>

</div>
<?php include "footer.php"?>
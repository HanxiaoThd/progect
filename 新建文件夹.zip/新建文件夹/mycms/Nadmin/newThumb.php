<?php
/**
 * Created by PhpStorm.
 * User: 韩笑Thd
 * Date: 2017/6/2
 * Time: 17:07
 */
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<input type="file" >
</body>
<script>
    window.onload=function () {

    }
//    var ajax=new XMLHttpRequest();
//    ajax.open("方式","地址")
//    ajax.send();
//    ajax.response();接收php返回的字符串
//    js手动创建form对象 form=new FromData();
//    form.append("file",filInfo);
</script>
</html>
